---
title: "Penetration Test Scope"
date: "2026-03-16"
type: "compliance"
company: "Acme SaaS Inc."
---
# Penetration Test Scope

> **Document Version:** 1.0  
> **Document Owner:** Acme SaaS Inc.  
> **Next Review Date:** 2027-03-16


**Organization:** Acme SaaS Inc.
**Last updated:** 2026-03-16
**Application URL:** [https://yoursite.com]
**Security contact:** privacy@acme.com

This document defines the recommended scope for penetration testing based on the services, API endpoints, authentication flows, and third-party integrations detected in the codebase. It should be provided to the penetration testing team as a starting point for engagement scoping.

## 1. Executive Summary

The Acme SaaS Inc. application uses 6 detected service(s) spanning the following categories:

- **monitoring**: 1 service(s)
- **auth**: 1 service(s)
- **ai**: 1 service(s)
- **analytics**: 1 service(s)
- **email**: 1 service(s)
- **payment**: 1 service(s)

### Risk Level Assessment

Key risk factors identified:

- Payment processing (PCI DSS scope)
- User authentication and session management
- AI/ML services processing user data
- 6 third-party integrations

## 2. Recommended Test Scope

### 2.1 Web Application Testing

| Test Area | Priority | Description |
| --- | --- | --- |
| OWASP Top 10 | Critical | Full coverage of current OWASP Top 10 vulnerabilities |
| Input validation | High | SQL injection, XSS, SSRF, command injection |
| Business logic | High | Application-specific logic flaws and abuse scenarios |
| Error handling | Medium | Information disclosure through error messages |
| HTTP security headers | Medium | CSP, HSTS, X-Frame-Options, etc. |
| Rate limiting | Medium | API abuse and brute-force protection |

### 2.2 Authentication & Session Management

Detected authentication services:

- **@supabase/supabase-js** — data: email, password hash, session data, user metadata

| Test Area | Priority | Description |
| --- | --- | --- |
| Login brute-force | Critical | Account lockout and rate limiting |
| Session management | Critical | Token generation, expiration, rotation |
| Password policy | High | Complexity requirements, breach database checks |
| OAuth flow | High | Authorization code interception, CSRF, redirect URI validation |
| Session fixation | High | Session ID regeneration after authentication |
| Account enumeration | Medium | Timing attacks on login/registration |
| MFA bypass | High | Multi-factor authentication bypass techniques |
| Privilege escalation | Critical | Horizontal and vertical privilege escalation |

**Auth flows to verify:**

- [ ] User registration and email verification
- [ ] Login with credentials (email/password)
- [ ] OAuth/social login flows
- [ ] Password reset / forgot password
- [ ] Session logout and token invalidation
- [ ] Account deletion and data cleanup
- [ ] Role-based access control enforcement
- [ ] Third-party auth provider webhook validation
- [ ] JWT token validation and signature verification

### 2.3 API Endpoint Testing

| Test Area | Priority | Description |
| --- | --- | --- |
| Authentication bypass | Critical | Access to endpoints without valid credentials |
| Authorization (IDOR) | Critical | Insecure direct object references |
| Mass assignment | High | Unintended parameter binding |
| API rate limiting | Medium | DoS prevention through rate limits |
| Input validation | High | Type coercion, boundary values, malformed requests |
| Response data leakage | Medium | Sensitive data in API responses |
| CORS configuration | Medium | Cross-origin request policy validation |
| GraphQL-specific | Medium | Introspection, batching attacks, depth limiting |

**API endpoints to test:**

- [ ] All user-facing REST endpoints
- [ ] GraphQL endpoints (if applicable)
- [ ] Webhook receiver endpoints
- [ ] File upload endpoints
- [ ] Search/filter endpoints (injection testing)
- [ ] Admin/internal API endpoints

### Payment Security Testing

Detected payment services:

- **stripe** — data: payment information, billing address, email, transaction history

| Test Area | Priority | Description |
| --- | --- | --- |
| Price manipulation | Critical | Client-side price/quantity tampering |
| Payment flow bypass | Critical | Order completion without payment |
| Webhook validation | Critical | Payment webhook signature verification |
| Refund abuse | High | Unauthorized refund initiation |
| PCI data exposure | Critical | Card data in logs, URLs, or responses |
| Race conditions | High | Double-spending or concurrent transaction abuse |

### AI/ML Security Testing

Detected AI services:

- **openai** — data: user prompts, conversation history, generated content

| Test Area | Priority | Description |
| --- | --- | --- |
| Prompt injection | Critical | Direct and indirect prompt injection attacks |
| Data exfiltration | High | Extracting training data or system prompts |
| Output manipulation | High | Causing harmful or unintended AI outputs |
| Token/cost abuse | Medium | Excessive API consumption attacks |
| Content filtering bypass | High | Bypassing safety filters |
| PII in prompts | High | Personal data exposure through AI interactions |

## 3. Third-Party Integration Assessment

The following third-party services should be assessed for secure integration:

| Service | Category | Security Considerations |
| --- | --- | --- |
| @sentry/node | monitoring | PII in error reports, dashboard access controls |
| @supabase/supabase-js | auth | OAuth flow security, token validation, session management |
| openai | ai | Prompt injection, data exfiltration, API key exposure |
| posthog | analytics | Data collection scope, cookie consent, script integrity |
| resend | email | SPF/DKIM/DMARC, header injection, content injection |
| stripe | payment | Webhook signature verification, PCI compliance, price integrity |

**For each integration, verify:**

- [ ] API keys are not exposed in client-side code or version control
- [ ] Webhook signatures are validated
- [ ] Minimum required permissions/scopes are used
- [ ] Error responses from third-party services are handled securely
- [ ] Timeout and retry logic prevents cascading failures
- [ ] TLS is enforced for all third-party API communications

## 4. Infrastructure Testing

| Test Area | Priority | Description |
| --- | --- | --- |
| TLS configuration | High | Certificate validity, cipher suites, protocol versions |
| DNS security | Medium | DNSSEC, SPF, DKIM, DMARC records |
| Cloud configuration | High | IAM policies, security groups, public exposure |
| Monitoring exposure | Medium | Sensitive data in monitoring dashboards/alerts |

## 5. Out of Scope

The following are excluded from the penetration test unless explicitly agreed:

- Denial of Service (DoS/DDoS) attacks against production infrastructure
- Social engineering attacks against employees
- Physical security assessments
- Third-party service infrastructure (only the integration is in scope)
- Automated vulnerability scanning without coordination

## 6. Recommended Methodology

- **Standard**: OWASP Testing Guide v4, PTES, NIST SP 800-115
- **Classification**: CVSS v3.1 for vulnerability scoring
- **Reporting**: Executive summary + detailed technical findings + remediation guidance
- **Retesting**: Include retest of critical and high findings within 30 days of remediation

## 7. Testing Environment

| Parameter | Value |
| --- | --- |
| Application URL | [https://yoursite.com] |
| Environment | Staging (recommended) |
| Test accounts | To be provided before engagement |
| VPN/IP allowlisting | To be coordinated |
| Security contact | privacy@acme.com |
| Emergency contact | To be provided before engagement |

## 8. Expected Deliverables

- [ ] Executive summary report suitable for leadership
- [ ] Detailed technical report with proof-of-concept for each finding
- [ ] CVSS-scored vulnerability list
- [ ] Remediation recommendations with priority ranking
- [ ] Raw evidence and screenshots
- [ ] Retest report (after remediation)

## Related Documents

- Security Policy (`SECURITY.md`)
- Vulnerability Scan (`VULNERABILITY_SCAN.md`)

---

*This document was auto-generated by [Codepliant](https://github.com/joechensmartz/codepliant) based on detected services and integrations. The scope should be reviewed and adjusted by your security team before engaging a penetration testing provider. This document does not constitute a complete security assessment.*