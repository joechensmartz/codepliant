---
title: "Cookie Consent Configuration"
date: "2026-03-16"
type: "compliance"
company: "Acme SaaS Inc."
---
{
  "version": "1.0.0",
  "generated_at": "2026-03-16T15:49:29.332Z",
  "project": "acme-saas",
  "company": "Acme SaaS Inc.",
  "consent_settings": {
    "require_explicit_consent": true,
    "show_on_first_visit": true,
    "respect_dnt": true,
    "cookie_name": "cookie_consent",
    "cookie_duration_days": 365,
    "position": "bottom"
  },
  "categories": [
    {
      "id": "strictly_necessary",
      "name": "Strictly Necessary",
      "description": "Essential cookies required for the website to function. These cannot be disabled.",
      "required": true,
      "default_state": "enabled"
    },
    {
      "id": "functional",
      "name": "Functional",
      "description": "Cookies that enable enhanced functionality like live chat, error tracking, and personalization.",
      "required": false,
      "default_state": "disabled"
    },
    {
      "id": "analytics",
      "name": "Analytics",
      "description": "Cookies that help us understand how visitors interact with our website by collecting anonymous usage data.",
      "required": false,
      "default_state": "disabled"
    },
    {
      "id": "advertising",
      "name": "Advertising",
      "description": "Cookies used to deliver relevant advertisements and track ad campaign performance.",
      "required": false,
      "default_state": "disabled"
    }
  ],
  "providers": [
    {
      "name": "@sentry/node",
      "category_id": "functional",
      "provider": "Sentry (Functional Software Inc)",
      "purpose": "Server-side error tracking",
      "cookies": [],
      "duration": "N/A",
      "privacy_policy_url": "https://sentry.io/privacy/"
    },
    {
      "name": "posthog",
      "category_id": "analytics",
      "provider": "PostHog Inc",
      "purpose": "Product analytics, session recording, and feature flags",
      "cookies": [
        "ph_*",
        "distinct_id"
      ],
      "duration": "Up to 1 year",
      "privacy_policy_url": "https://posthog.com/privacy"
    },
    {
      "name": "stripe",
      "category_id": "strictly_necessary",
      "provider": "Stripe Inc",
      "purpose": "Payment processing (required for transactions)",
      "cookies": [
        "__stripe_mid",
        "__stripe_sid"
      ],
      "duration": "Up to 1 year",
      "privacy_policy_url": "https://stripe.com/privacy"
    },
    {
      "name": "@supabase/supabase-js",
      "category_id": "strictly_necessary",
      "provider": "@supabase/supabase-js",
      "purpose": "Authentication and session management",
      "cookies": [
        "_supabase_supabase_js_session"
      ],
      "duration": "Session",
      "privacy_policy_url": ""
    }
  ],
  "cmp_integration": {
    "onetrust": {
      "category_mapping": {
        "strictly_necessary": "C0001",
        "functional": "C0003",
        "analytics": "C0002",
        "advertising": "C0004"
      }
    },
    "cookieyes": {
      "category_mapping": {
        "strictly_necessary": "necessary",
        "functional": "functional",
        "analytics": "analytics",
        "advertising": "advertisement"
      }
    },
    "cookiebot": {
      "category_mapping": {
        "strictly_necessary": "necessary",
        "functional": "preferences",
        "analytics": "statistics",
        "advertising": "marketing"
      }
    }
  }
}
