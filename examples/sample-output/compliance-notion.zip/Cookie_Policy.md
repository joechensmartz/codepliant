---
title: "Cookie Policy"
date: "2026-03-16"
type: "compliance"
company: "Acme SaaS Inc."
---
# Cookie Policy

> **Document Version:** 1.0  
> **Document Owner:** Acme SaaS Inc.  
> **Next Review Date:** 2027-03-16


**Last Updated:** 2026-03-16

**Project:** acme-saas

## Related Documents

- Privacy Policy (`PRIVACY_POLICY.md`)
- Cookie Inventory (`COOKIE_INVENTORY.md`)
- Consent Management Guide (`CONSENT_MANAGEMENT_GUIDE.md`)

---

## 1. What Are Cookies

Cookies are small text files stored on your device when you visit a website. They serve various purposes including remembering your preferences, analyzing site usage, and enabling functionality.

## 2. Legal Basis for Cookies

Under Article 5(3) of the ePrivacy Directive (2002/58/EC), storing or accessing information on a user's device requires prior informed consent, except where the cookie is strictly necessary to provide a service explicitly requested by the user.

- **Strictly necessary cookies:** Exempt from the consent requirement under ePrivacy Directive Art. 5(3) because they are essential for providing the service you have requested. These cookies are placed based on our legitimate interest under GDPR Art. 6(1)(f).
- **All other cookies (analytics, advertising, functional):** Placed only with your prior consent under GDPR Art. 6(1)(a) and ePrivacy Directive Art. 5(3). Non-essential cookies are blocked until you provide consent.

## 3. Your Consent

In accordance with Article 5(3) of the ePrivacy Directive and the GDPR, Acme SaaS Inc. obtains your consent before placing any non-essential cookies on your device.

**How we obtain consent:**
- A cookie consent banner is displayed on your first visit
- Non-essential cookies are blocked until you provide consent (prior-consent model)
- You can accept all, reject all, or customise your preferences by cookie category
- Accept and reject options are presented with equal prominence

**Cookie categories requiring consent:**
- Analytics cookies
- Marketing/advertising cookies (if applicable)
- Functional cookies that are not strictly necessary

**Consent records:** We log your consent decision, including the date, time, and categories selected, as required by the GDPR's accountability principle (Art. 5(2)).

**Withdrawing consent:** You can withdraw or change your cookie consent at any time by:
- Clicking the "Cookie Preferences" link in our website footer
- Adjusting your browser settings to block or delete cookies
- Contacting us at privacy@acme.com

Withdrawal of consent is as easy as giving consent. Upon withdrawal, we will cease using the relevant cookies, though some data already collected may be retained as described in our Privacy Policy.

## 4. How We Use Cookies

We use cookies and similar technologies for the following purposes:

### Strictly Necessary Cookies

These cookies are essential for the website to function and cannot be switched off. They do not require consent under the ePrivacy Directive because they are necessary to provide a service you have explicitly requested.

| Cookie | Purpose | Duration |
|--------|---------|----------|
| Session cookie | Maintains your login session | Session |
| Auth token | Authenticates your identity | Varies |
| CSRF token | Prevents cross-site request forgery | Session |

### Optional Cookies — Analytics

These cookies help us understand how visitors interact with our website. They are **not strictly necessary** and are only placed with your prior consent.

| Service | Cookies | Purpose | Duration |
|---------|---------|---------|----------|
| posthog | ph_*, distinct_id | Product analytics, session recording | 1 year |

> **Consent required:** These cookies are only set after you have given your consent via our cookie consent banner. If you do not consent, these cookies will not be placed and the associated analytics features will not function.

## 5. Managing Cookies

You can control cookies through:

- **Cookie consent banner:** Use our cookie consent tool to manage your preferences (displayed on first visit and accessible via the "Cookie Preferences" link)
- **Browser settings:** Most browsers allow you to block or delete cookies
- **Opt-out links:** Visit the following links to opt out of specific services:

## 6. Third-Party Cookies

Some third-party services we use may set their own cookies:

- **posthog**: Used for user behavior, session recordings, feature flag usage
- **@supabase/supabase-js**: Used for email, password hash, session data

These third parties have their own cookie and privacy policies.

## 7. Global Privacy Control (GPC)

We recognize the Global Privacy Control (GPC) signal. When we detect a GPC signal from your browser:
- We treat it as a valid opt-out request
- Non-essential cookies are blocked
- Your preference is respected across our service

To enable GPC, install a supporting browser or extension. Learn more at https://globalprivacycontrol.org

## 8. Updates to This Policy

We may update this Cookie Policy from time to time. Changes will be posted on this page with an updated revision date.

## 9. Contact

For questions about our use of cookies, please contact:

- **Email:** privacy@acme.com

---

*This cookie policy was generated by [Codepliant](https://github.com/codepliant/codepliant) based on automated code analysis. Review and customize it for your specific use case.*